function replaceModel() 
   txd = engineLoadTXD("10.txd")
   engineImportTXD(txd, 10)
   dff = engineLoadDFF("10.dff")
   engineReplaceModel(dff, 10)
end
addEventHandler ( "onClientResourceStart", getResourceRootElement(getThisResource()), replaceModel)