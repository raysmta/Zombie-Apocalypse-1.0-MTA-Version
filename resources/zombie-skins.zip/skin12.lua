function replaceModel() 
  txd = engineLoadTXD("12.txd")
  engineImportTXD(txd, 12)
  dff = engineLoadDFF("12.dff")
  engineReplaceModel(dff, 12)
end
addEventHandler ( "onClientResourceStart", getResourceRootElement(getThisResource()), replaceModel)