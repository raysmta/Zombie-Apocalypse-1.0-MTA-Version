function replaceModel() 
  txd = engineLoadTXD("13.txd")
  engineImportTXD(txd, 13)
  dff = engineLoadDFF("13.dff")
  engineReplaceModel(dff, 13)
end
addEventHandler ( "onClientResourceStart", getResourceRootElement(getThisResource()), replaceModel)