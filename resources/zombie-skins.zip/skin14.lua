function replaceModel() 
  txd = engineLoadTXD("14.txd")
  engineImportTXD(txd, 14)
  dff = engineLoadDFF("14.dff")
  engineReplaceModel(dff, 14)
end
addEventHandler ( "onClientResourceStart", getResourceRootElement(getThisResource()), replaceModel)