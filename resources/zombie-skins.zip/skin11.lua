function replaceModel() 
  txd = engineLoadTXD("11.txd")
  engineImportTXD(txd, 11)
  dff = engineLoadDFF("11.dff")
  engineReplaceModel(dff, 11)
end
addEventHandler ( "onClientResourceStart", getResourceRootElement(getThisResource()), replaceModel)