    addEvent ( "onZombieWasted", true )
    addEventHandler ( "onZombieWasted", root,
        function ( theKiller )
            exports.exp_system:addPlayerEXP ( theKiller, math.random(1, 10))
        end
    )